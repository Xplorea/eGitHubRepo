package com.domain.repository;

import java.awt.List;

import com.domain.model.Product;

public class PostgreSQLRepository implements ProductRepository{

	@Override
	public java.util.List<Product> getProducts() {
		return null;
	}

}

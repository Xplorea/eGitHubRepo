package com.domain.service;

import java.util.List;

import com.domain.model.Product;

public interface ProductService {
	List<Product> getProducts();
}

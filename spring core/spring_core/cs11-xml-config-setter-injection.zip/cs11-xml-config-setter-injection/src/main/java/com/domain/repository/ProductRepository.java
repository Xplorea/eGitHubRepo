package com.domain.repository;

import java.util.List;

import com.domain.model.Product;

public interface ProductRepository {
List<Product> getProducts();
}

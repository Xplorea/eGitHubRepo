package com.domain.service;

import java.util.List;

import com.domain.model.Customer;

public interface CustomerService {

	List<Customer> findAll();

}